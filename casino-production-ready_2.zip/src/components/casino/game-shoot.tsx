'use client';

import { useState, useCallback, useMemo } from 'react';
import { useReducedMotion } from 'framer-motion';
import { ArrowLeft, RotateCcw, Target, Crosshair } from 'lucide-react';
import { PostedAmount } from '@/casino/components/casino/PostedAmount';

interface Props {
  onBack: () => void;
  initialBalance: number;
}

const QUICK_BETS = [1, 5, 10, 50, 100];

/* ── Local RNG (seeded) ── */
function seededRandom(seed: string): number {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    const char = seed.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return (Math.abs(hash) % 10000) / 10000;
}

function generateTargets(chosenMult: number, seed: string): number[] {
  const targets: number[] = [];
  // Generate 4 random multipliers
  for (let i = 0; i < 4; i++) {
    const r = seededRandom(seed + ':' + i);
    // Distribute: 0x, low, medium, some high
    if (r < 0.2) targets.push(0);
    else if (r < 0.5) targets.push(Number((r * 5).toFixed(1)));
    else if (r < 0.8) targets.push(Number((r * 8).toFixed(1)));
    else targets.push(Number((r * 10).toFixed(1)));
  }
  // Ensure at least one target >= chosenMult
  const guaranteedIdx = Math.floor(seededRandom(seed + ':guaranteed') * 5);
  const guaranteedVal = Math.max(chosenMult, Number((chosenMult + seededRandom(seed + ':bonus') * (10 - chosenMult)).toFixed(1)));
  targets.splice(guaranteedIdx, 0, Number(Math.min(10, guaranteedVal).toFixed(1)));

  return targets.slice(0, 5);
}

/* ── SVG Target Component ── */
function TargetSVG({ multiplier, revealed, hit, isResult, won, shooting, index }: {
  multiplier: number;
  revealed: boolean;
  hit: boolean;
  isResult: boolean;
  won: boolean;
  shooting: boolean;
  index: number;
}) {
  const color = multiplier >= 5 ? 'var(--color-lime)' : multiplier >= 2 ? 'var(--color-win)' : multiplier >= 1 ? '#60a5fa' : multiplier > 0 ? 'var(--color-pending)' : 'var(--color-loss)';
  const reduced = useReducedMotion();

  return (
    <div className="flex flex-col items-center gap-2">
      <div
        className="relative"
        style={{
          width: '120px',
          height: '120px',
          cursor: !revealed && !shooting ? 'crosshair' : 'default',
          animation: !revealed && !shooting && !reduced ? `targetBob ${2 + index * 0.15}s ease-in-out infinite` : 'none',
        } as React.CSSProperties}
      >
        <style>{`
          @keyframes targetBob {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-6px); }
          }
          @keyframes targetShatter {
            0% { transform: scale(1) rotate(0deg); opacity: 1; }
            30% { transform: scale(1.15) rotate(5deg); opacity: 1; }
            100% { transform: scale(0.3) rotate(45deg); opacity: 0; }
          }
          @keyframes targetReveal {
            0% { transform: scale(1.3); opacity: 0; }
            50% { transform: scale(0.95); opacity: 1; }
            100% { transform: scale(1); opacity: 1; }
          }
          @keyframes winBurst {
            0% { transform: scale(1); filter: brightness(1); }
            30% { transform: scale(1.1); filter: brightness(1.5); }
            100% { transform: scale(1); filter: brightness(1); }
          }
          @keyframes lossFall {
            0% { transform: translateY(0) rotate(0); opacity: 1; }
            100% { transform: translateY(40px) rotate(15deg); opacity: 0.5; }
          }
          @keyframes particleBurst {
            0% { transform: translate(0, 0) scale(1); opacity: 1; }
            100% { transform: translate(var(--px), var(--py)) scale(0); opacity: 0; }
          }
        `}</style>

        <svg width="120" height="120" viewBox="0 0 120 120" className="w-full h-full">
          <defs>
            <radialGradient id={`targetGlow-${index}`} cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor={color} stopOpacity={isResult && won ? 0.4 : 0.15} />
              <stop offset="100%" stopColor={color} stopOpacity="0" />
            </radialGradient>
            <filter id={`targetFilter-${index}`}>
              <feGaussianBlur stdDeviation="2" result="blur" />
              <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
            </filter>
          </defs>

          {/* Hit animation wrapper */}
          <g style={{
            animation: reduced ? 'none' : hit ? 'targetShatter 0.5s ease-out forwards' : revealed && !hit ? 'targetReveal 0.4s ease-out forwards' : 'none',
          }}>
            {/* Glow */}
            <circle cx="60" cy="60" r="55" fill={`url(#targetGlow-${index})`} />

            {/* Outer ring */}
            <circle cx="60" cy="60" r="50" fill="none" stroke={color} strokeWidth="2" strokeOpacity={revealed ? 0.6 : 0.2} />
            <circle cx="60" cy="60" r="40" fill={revealed ? `${color}15` : 'rgba(255,255,255,0.03)'} stroke={color} strokeWidth="1.5" strokeOpacity={revealed ? 0.5 : 0.15} />
            <circle cx="60" cy="60" r="28" fill={revealed ? `${color}22` : 'rgba(255,255,255,0.02)'} stroke={color} strokeWidth="1.5" strokeOpacity={revealed ? 0.4 : 0.1} />
            <circle cx="60" cy="60" r="16" fill={revealed ? color : 'rgba(255,255,255,0.05)'} fillOpacity={revealed ? 0.3 : 1} />

            {/* Bullseye center */}
            <circle cx="60" cy="60" r="5" fill={revealed ? color : 'rgba(255,255,255,0.15)'} />

            {/* Crosshair lines */}
            {!revealed && (
              <>
                <line x1="60" y1="5" x2="60" y2="20" stroke={color} strokeWidth="1" strokeOpacity="0.3" />
                <line x1="60" y1="100" x2="60" y2="115" stroke={color} strokeWidth="1" strokeOpacity="0.3" />
                <line x1="5" y1="60" x2="20" y2="60" stroke={color} strokeWidth="1" strokeOpacity="0.3" />
                <line x1="100" y1="60" x2="115" y2="60" stroke={color} strokeWidth="1" strokeOpacity="0.3" />
              </>
            )}

            {/* Multiplier text or "?" */}
            {revealed ? (
              <text x="60" y="60" textAnchor="middle" dominantBaseline="central"
                fill={color} fontSize="18" fontWeight="800" fontFamily="monospace"
                filter={`url(#targetFilter-${index})`}
              >
                {multiplier}x
              </text>
            ) : (
              <text x="60" y="60" textAnchor="middle" dominantBaseline="central"
                fill="rgba(255,255,255,0.35)" fontSize="28" fontWeight="800"
              >
                ?
              </text>
            )}
          </g>
        </svg>

        {/* Impact particles */}
        {isResult && won && revealed && !reduced && (
          <div className="absolute inset-0 pointer-events-none">
            {Array.from({ length: 8 }).map((_, i) => {
              const angle = (i / 8) * Math.PI * 2;
              const dist = 60;
              return (
                <div key={i} className="absolute w-2 h-2 rounded-full"
                  style={{
                    background: color,
                    left: '50%', top: '50%',
                    marginLeft: '-4px', marginTop: '-4px',
                    ['--px' as string]: `${Math.cos(angle) * dist}px`,
                    ['--py' as string]: `${Math.sin(angle) * dist}px`,
                    animation: `particleBurst 0.6s ease-out ${i * 0.05}s forwards`,
                    opacity: 0,
                  }}
                />
              );
            })}
          </div>
        )}

        {/* Result border glow */}
        {isResult && revealed && (
          <div className="absolute inset-0 rounded-full pointer-events-none"
            style={{
              border: `2px solid ${won ? 'var(--color-win)' : 'var(--color-loss)'}`,
              boxShadow: won ? '0 0 30px color-mix(in oklab, var(--color-lime) 40%, transparent), inset 0 0 20px color-mix(in oklab, var(--color-lime) 10%, transparent)' : '0 0 30px color-mix(in oklab, var(--color-loss) 40%, transparent), inset 0 0 20px color-mix(in oklab, var(--color-loss) 10%, transparent)',
              animation: won ? 'winBurst 0.8s ease-out' : 'lossFall 0.8s ease-out',
            }}
          />
        )}
      </div>

      {/* Label below */}
      <span className="text-[10px] font-medium uppercase tracking-wider"
        style={{ color: revealed ? color : 'rgba(255,255,255,0.25)' }}>
        {revealed ? `${multiplier}x Multiplier` : `Target ${index + 1}`}
      </span>
    </div>
  );
}

export function ShootGame({ onBack, initialBalance }: Props) {
  const [balance, setBalance] = useState(initialBalance);
  const [betAmount, setBetAmount] = useState(5);
  const [targetMult, setTargetMult] = useState(2);
  const [gameState, setGameState] = useState<'idle' | 'ready' | 'shooting' | 'result'>('idle');
  const [targets, setTargets] = useState<number[]>([]);
  const [chosenIdx, setChosenIdx] = useState<number | null>(null);
  const [seed, setSeed] = useState('');
  const [result, setResult] = useState<null | { won: boolean; multiplier: number; payout: number }>(null);
  const [history, setHistory] = useState<Array<{ result: string; target: number; mult: number; payout: number }>>([]);
  const [flash, setFlash] = useState(false);
  const reduced = useReducedMotion();

  const potentialWin = useMemo(() => betAmount * targetMult, [betAmount, targetMult]);

  const startRound = useCallback(() => {
    if (betAmount <= 0 || betAmount > balance) return;
    const newSeed = Date.now().toString(36) + Math.random().toString(36).slice(2);
    const newTargets = generateTargets(targetMult, newSeed);
    setSeed(newSeed);
    setTargets(newTargets);
    setChosenIdx(null);
    setResult(null);
    setGameState('ready');
    setBalance(b => b - betAmount);
  }, [betAmount, balance, targetMult]);

  const shootTarget = useCallback((idx: number) => {
    if (gameState !== 'ready') return;
    setGameState('shooting');
    setChosenIdx(idx);
    if (!reduced) {
      setFlash(true);
      setTimeout(() => setFlash(false), 200);
    }

    setTimeout(() => {
      const mult = targets[idx];
      const won = mult >= targetMult;
      const payout = won ? betAmount * mult : 0;

      setResult({ won, multiplier: mult, payout });
      setBalance(b => b + payout);
      setGameState('result');
      setHistory(prev => [{
        result: won ? 'win' : 'lose',
        target: targetMult,
        mult,
        payout: won ? payout - betAmount : -betAmount,
      }, ...prev].slice(0, 10));
    }, 600);
  }, [gameState, targets, targetMult, betAmount, reduced]);

  const resetRound = useCallback(() => {
    setGameState('idle');
    setTargets([]);
    setChosenIdx(null);
    setResult(null);
  }, []);

  const targetOptions = [1, 2, 3, 5, 7, 10];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button onClick={onBack} className="p-2 rounded-lg transition-colors hover:bg-white/5" style={{ color: 'rgba(255,255,255,0.7)' }}>
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-2">
          <Crosshair className="w-5 h-5" style={{ color: 'var(--color-lime)' }} />
          <div>
            <h1 className="text-xl font-bold text-white">Target Shoot</h1>
            <p className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>Pick a target multiplier, then shoot!</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Game Area */}
        <div className="lg:col-span-3">
          <div
            className="relative rounded-xl overflow-hidden"
            style={{
              background: 'var(--color-bg)',
              border: '1px solid color-mix(in oklab, var(--color-lime) 8%, transparent)',
              animation: gameState === 'shooting' && !reduced ? 'shootRecoil 0.3s cubic-bezier(0.16, 1, 0.3, 1)' : 'none',
            }}
          >
            <style>{`
              @keyframes shootRecoil {
                0% { transform: translateY(0) scale(1); }
                25% { transform: translateY(5px) scale(0.995); }
                100% { transform: translateY(0) scale(1); }
              }
              @keyframes muzzleFlash {
                0% { opacity: 1; }
                100% { opacity: 0; }
              }
            `}</style>
            {/* Muzzle flash */}
            {flash && !reduced && (
              <div
                className="pointer-events-none absolute inset-0 z-20"
                style={{
                  background: 'radial-gradient(circle at 50% 40%, rgba(255,255,255,0.4), color-mix(in oklab, var(--color-lime) 18%, transparent) 30%, transparent 60%)',
                  animation: 'muzzleFlash 0.18s ease-out forwards',
                }}
              />
            )}
            {/* Target Display */}
            <div className="py-8 px-4">
              {gameState === 'idle' ? (
                <div className="flex flex-col items-center justify-center py-8 gap-4">
                  <div className="w-20 h-20 rounded-full flex items-center justify-center"
                    style={{
                      background: 'color-mix(in oklab, var(--color-lime) 8%, transparent)',
                      border: '2px solid color-mix(in oklab, var(--color-lime) 20%, transparent)',
                    }}
                  >
                    <Target className="w-10 h-10" style={{ color: 'color-mix(in oklab, var(--color-lime) 50%, transparent)' }} />
                  </div>
                  <p className="text-sm font-medium" style={{ color: 'rgba(255,255,255,0.5)' }}>
                    Set your target and press Start to begin
                  </p>
                </div>
              ) : (
                <>
                  <div className="text-center mb-4">
                    <span className="text-[10px] uppercase tracking-wider font-medium" style={{ color: 'rgba(255,255,255,0.3)' }}>
                      Shoot a target — find {targetMult}x or higher to win!
                    </span>
                  </div>
                  <div className="flex flex-wrap justify-center gap-4 sm:gap-6">
                    {targets.map((mult, i) => (
                      <button
                        key={i}
                        onClick={() => shootTarget(i)}
                        disabled={gameState !== 'ready'}
                        className="transition-transform hover:scale-105 active:scale-95"
                        style={{ opacity: gameState === 'shooting' && chosenIdx !== i ? 0.3 : 1 }}
                      >
                        <TargetSVG
                          multiplier={mult}
                          revealed={gameState === 'shooting' || gameState === 'result'}
                          hit={gameState === 'shooting' && chosenIdx === i}
                          isResult={gameState === 'result' && chosenIdx === i}
                          won={gameState === 'result' ? (result?.won ?? false) : false}
                          shooting={gameState === 'shooting'}
                          index={i}
                        />
                      </button>
                    ))}
                  </div>

                  {/* Result banner */}
                  {gameState === 'result' && result && (
                    <div className="mt-6 text-center" style={{ animation: 'winBurst 0.5s ease-out' }}>
                      <style>{`
                        @keyframes winBurst {
                          0% { transform: scale(0.8); opacity: 0; }
                          60% { transform: scale(1.05); }
                          100% { transform: scale(1); opacity: 1; }
                        }
                      `}</style>
                      <div className="inline-flex items-center gap-3 px-6 py-3 rounded-xl"
                        style={{
                          background: result.won
                            ? 'linear-gradient(135deg, color-mix(in oklab, var(--color-lime) 15%, transparent), color-mix(in oklab, var(--color-lime) 10%, transparent))'
                            : 'linear-gradient(135deg, color-mix(in oklab, var(--color-loss) 15%, transparent), color-mix(in oklab, var(--color-loss) 5%, transparent))',
                          border: `1px solid ${result.won ? 'color-mix(in oklab, var(--color-lime) 30%, transparent)' : 'color-mix(in oklab, var(--color-loss) 30%, transparent)'}`,
                        }}
                      >
                        <span className={`text-2xl font-black tabular-nums ${result.won ? 'text-lime' : 'text-loss'}`}>
                          {result.won ? `+$${result.payout.toFixed(2)}` : `-$${betAmount.toFixed(2)}`}
                        </span>
                        <span className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>
                          Hit {result.multiplier}x — needed {targetMult}x
                        </span>
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>

            {/* Bottom bar: target mult selector */}
            <div className="px-4 py-4" style={{ borderTop: '1px solid rgba(255,255,255,0.05)', background: 'rgba(0,0,0,0.2)' }}>
              <div className="flex items-center justify-between flex-wrap gap-3">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase tracking-wider font-medium" style={{ color: 'rgba(255,255,255,0.35)' }}>Target Multiplier</span>
                  <div className="flex gap-1.5">
                    {targetOptions.map(opt => (
                      <button key={opt} onClick={() => setTargetMult(opt)}
                        disabled={gameState !== 'idle'}
                        className="px-3 py-1.5 rounded-lg text-xs font-bold transition-all"
                        style={targetMult === opt
                          ? { background: 'color-mix(in oklab, var(--color-lime) 15%, transparent)', color: 'var(--color-lime)', border: '1px solid color-mix(in oklab, var(--color-lime) 30%, transparent)', boxShadow: '0 0 10px color-mix(in oklab, var(--color-lime) 10%, transparent)' }
                          : { background: 'rgba(255,255,255,0.04)', color: 'rgba(255,255,255,0.4)', border: '1px solid rgba(255,255,255,0.06)' }}
                      >
                        {opt}x
                      </button>
                    ))}
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  {gameState === 'result' && (
                    <button onClick={resetRound}
                      className="px-4 py-2 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all"
                      style={{ background: 'rgba(255,255,255,0.06)', color: 'rgba(255,255,255,0.5)', border: '1px solid rgba(255,255,255,0.1)' }}
                    >
                      New Round
                    </button>
                  )}
                  <button onClick={gameState === 'idle' ? startRound : resetRound}
                    disabled={(gameState !== 'idle' && gameState !== 'result') || betAmount <= 0 || betAmount > balance}
                    className="px-6 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all disabled:opacity-30"
                    style={{
                      background: 'var(--color-lime)',
                      color: 'var(--color-bg)',
                      boxShadow: '0 0 15px color-mix(in oklab, var(--color-lime) 25%, transparent), inset 0 1px 0 rgba(255,255,255,0.2)',
                    }}
                  >
                    {gameState === 'idle' ? 'Start Round' : 'New Round'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="space-y-3">
          {/* Balance */}
          <div className="rounded-xl p-4" style={{ background: 'var(--color-surface)', border: '1px solid color-mix(in oklab, var(--color-lime) 8%, transparent)' }}>
            <p className="text-[10px] uppercase tracking-wider font-medium" style={{ color: 'rgba(255,255,255,0.35)' }}>Balance</p>
            <PostedAmount value={balance} format={(n) => `$${n.toFixed(2)}`} className="mt-1 text-2xl font-bold text-lime" />
          </div>

          {/* Bet Amount */}
          <div className="rounded-xl p-4" style={{ background: 'var(--color-surface)', border: '1px solid color-mix(in oklab, var(--color-lime) 8%, transparent)' }}>
            <p className="text-[10px] uppercase tracking-wider font-medium mb-2" style={{ color: 'rgba(255,255,255,0.35)' }}>Bet Amount</p>
            <div className="flex gap-1.5 mb-2 flex-wrap">
              {QUICK_BETS.map(v => (
                <button key={v} onClick={() => setBetAmount(v)}
                  className="px-2.5 py-1.5 rounded-lg text-[10px] font-semibold transition-all"
                  style={betAmount === v
                    ? { background: 'color-mix(in oklab, var(--color-lime) 15%, transparent)', color: 'var(--color-lime)', border: '1px solid color-mix(in oklab, var(--color-lime) 30%, transparent)' }
                    : { background: 'rgba(255,255,255,0.04)', color: 'rgba(255,255,255,0.45)', border: '1px solid rgba(255,255,255,0.06)' }}
                  disabled={gameState !== 'idle'}
                >
                  ${v}
                </button>
              ))}
            </div>
            <input type="number" value={betAmount} onChange={e => setBetAmount(Math.max(0, Number(e.target.value)))}
              className="w-full h-8 px-3 rounded-lg text-sm font-bold text-white text-center outline-none"
              style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
              disabled={gameState !== 'idle'}
            />
          </div>

          {/* Game Info */}
          <div className="rounded-xl p-4" style={{ background: 'var(--color-surface)', border: '1px solid color-mix(in oklab, var(--color-lime) 8%, transparent)' }}>
            <p className="text-[10px] uppercase tracking-wider font-medium mb-3" style={{ color: 'rgba(255,255,255,0.35)' }}>Game Info</p>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-[10px]" style={{ color: 'rgba(255,255,255,0.4)' }}>Target Multiplier</span>
                <span className="text-xs font-bold" style={{ color: 'var(--color-lime)' }}>{targetMult}x</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[10px]" style={{ color: 'rgba(255,255,255,0.4)' }}>Potential Win</span>
                <span className="text-xs font-bold text-win">${potentialWin.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[10px]" style={{ color: 'rgba(255,255,255,0.4)' }}>Targets</span>
                <span className="text-xs font-bold" style={{ color: 'rgba(255,255,255,0.6)' }}>5</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[10px]" style={{ color: 'rgba(255,255,255,0.4)' }}>Min Win</span>
                <span className="text-xs font-bold" style={{ color: 'rgba(255,255,255,0.6)' }}>0x</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[10px]" style={{ color: 'rgba(255,255,255,0.4)' }}>Max Win</span>
                <span className="text-xs font-bold" style={{ color: 'var(--color-lime)' }}>10x</span>
              </div>
            </div>
          </div>

          {/* How to play */}
          <div className="rounded-xl p-4" style={{ background: 'var(--color-surface)', border: '1px solid color-mix(in oklab, var(--color-lime) 8%, transparent)' }}>
            <p className="text-[10px] uppercase tracking-wider font-medium mb-2" style={{ color: 'rgba(255,255,255,0.35)' }}>How to Play</p>
            <div className="space-y-1.5">
              <div className="flex items-start gap-2">
                <span className="w-4 h-4 rounded-full flex items-center justify-center text-[8px] font-bold flex-shrink-0" style={{ background: 'color-mix(in oklab, var(--color-lime) 15%, transparent)', color: 'var(--color-lime)' }}>1</span>
                <span className="text-[10px] leading-relaxed" style={{ color: 'rgba(255,255,255,0.45)' }}>Choose a target multiplier</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="w-4 h-4 rounded-full flex items-center justify-center text-[8px] font-bold flex-shrink-0" style={{ background: 'color-mix(in oklab, var(--color-lime) 15%, transparent)', color: 'var(--color-lime)' }}>2</span>
                <span className="text-[10px] leading-relaxed" style={{ color: 'rgba(255,255,255,0.45)' }}>Start the round — 5 targets appear</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="w-4 h-4 rounded-full flex items-center justify-center text-[8px] font-bold flex-shrink-0" style={{ background: 'color-mix(in oklab, var(--color-lime) 15%, transparent)', color: 'var(--color-lime)' }}>3</span>
                <span className="text-[10px] leading-relaxed" style={{ color: 'rgba(255,255,255,0.45)' }}>Shoot one target — if it&apos;s ≥ your target, you win!</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* History */}
      {history.length > 0 && (
        <div className="rounded-xl p-4" style={{ background: 'var(--color-surface)', border: '1px solid color-mix(in oklab, var(--color-lime) 8%, transparent)' }}>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'rgba(255,255,255,0.5)' }}>Bet History</h3>
            <button onClick={() => setHistory([])} className="text-[10px] flex items-center gap-1 transition-colors" style={{ color: 'rgba(255,255,255,0.25)' }}>
              <RotateCcw className="w-3 h-3" /> Clear
            </button>
          </div>
          <div className="max-h-40 overflow-y-auto space-y-1" style={{ scrollbarWidth: 'thin', scrollbarColor: 'color-mix(in oklab, var(--color-lime) 20%, transparent) transparent' }}>
            {history.map((h, i) => (
              <div key={i} className="flex items-center justify-between py-1.5 px-3 rounded-lg transition-colors"
                style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.03)' }}>
                <div className="flex items-center gap-2">
                  <span className={`text-[9px] font-bold px-2 py-0.5 rounded ${h.result === 'win' ? 'bg-win/10 text-win' : 'bg-loss/10 text-loss'}`}>
                    {h.result.toUpperCase()}
                  </span>
                  <span className="text-[10px] font-mono" style={{ color: 'rgba(255,255,255,0.4)' }}>
                    Target {h.target}x → hit <span style={{ color: h.mult >= 5 ? 'var(--color-lime)' : h.mult >= 2 ? 'var(--color-win)' : h.mult > 0 ? 'var(--color-pending)' : 'var(--color-loss)' }}>{h.mult}x</span>
                  </span>
                </div>
                <span className={`text-xs font-bold tabular-nums ${h.result === 'win' ? 'text-win' : 'text-loss'}`}>
                  {h.payout >= 0 ? '+' : ''}{h.payout.toFixed(2)}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
